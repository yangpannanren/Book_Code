r = .125;
h = 1.;
% Compute wavelength
lambda = 3.0e+8 /9.5e+9;
cylinder (r, h,lambda);