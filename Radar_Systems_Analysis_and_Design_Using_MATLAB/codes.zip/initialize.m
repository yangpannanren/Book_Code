clear all
sigma0 = -20;
thetaA = 1;
thetaE = 2;
SL = -20;
hr = 3;
ht = 100;
pt = 75;
f0 = 5.6e9;
b = 1e6;
t0 = 290;
f = 6;
l = 10;
ant_id = 1;
Rmin = 2;
Rmax = 50;